### Replicating the Solutions

**Clone the Repository:**
git clone [repository_url]
cd [repository_folder]

### Dependencies
You need to install following libraries to run some tasks
1: pandas
2: numpy
3: matplotlib
4: scipy
5: yfinance

You can install these libraries through pip or brew

### Run the code
You need to open all tasks in jupitor notebook. You can launch jupitor notebook by after downloading "anaconda"

After the tasks open in jupitor notebook, you can run each cell and look at the output